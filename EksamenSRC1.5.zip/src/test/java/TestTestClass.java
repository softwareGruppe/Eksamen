import forms.rentYourCarGUI;
import org.junit.jupiter.api.Test;
import tools.Functions;

import static org.junit.jupiter.api.Assertions.*;

public class TestTestClass {
    //public rentYourCarGUI rentYourCarGUI = Main.mainWindow;

    @Test
    public void Create_Ad_Tests() { //13 tester + 1 "suksess"
        Create_Ad_RegNr_Is_Empty();
        Create_Ad_RegisteryNumber_Too_Short();
    }
    public void Create_Ad_RegNr_Is_Empty() { assertEquals(Functions.CreateAdFieldCheck("", "T", "T", "T", "T", "T", "T", "T"), "Registration Number field cannot be empty"); }
    public void Create_Ad_RegisteryNumber_Too_Short() { assertEquals(Functions.CreateAdFieldCheck("AB12", "T", "T", "T", "T", "T", "T", "T"), "Price can only contain numbers"); }

    @Test
    public void Create_Ad_Succeeds_And_Does_Not_Return_Error_Message() {
        assertEquals(Functions.CreateAdFieldCheck("AB12345", "BMW", "Bazzar", "2029", "109", "90", "Automatic", "Diesel"), ""); }

    @Test
    public void Booking_End_Time_Is_Empty() { assertEquals(Functions.BookListingFieldCheck("B", "B", "B", "B", "B", "B", "B", "B", "B", ""), "Booking Date cannot be empty"); }
}
