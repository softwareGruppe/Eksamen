package models;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sun.tools.javac.Main;
import tools.JsonFileHandler;

import java.util.ArrayList;

public class Booking extends Car{
    @JsonProperty
    private int ID;
    private int car_renter_id;
    private int car_id;
    @JsonProperty
    private String startDate;
    @JsonProperty
    private String startTime;
    @JsonProperty
    private String endDate;
    @JsonProperty
    private String endTime;


    @Override
    public String toString() {
        return "Booking: " + ID + "  Car: " + FindCar(car_id).toString() + "  StartDate: " + startDate + "T" + startTime;
    }

    public String GetInfo() {
        return "Booking for car " + FindCar(car_id).toString() + " starting on " + startDate + "T" + startTime + "  ends " + endDate + "T" + endTime;
    }

    Car FindCar(int car_id) {
        ArrayList<Car> cars;
        JsonFileHandler jfh = new JsonFileHandler();
        cars = jfh.readCarFromJSONfile();
        Car returnCar;
        returnCar = cars.get(car_id);
        return returnCar;
    }

    public Booking() {
        //creating an empty constructor to prevent error when deserializing and reading from json file.
    }

    public Booking(int ID, int car_renter_id, int car_id, String startDate, String startTime, String endDate, String endTime) {
        this.ID = ID;
        this.car_renter_id = car_renter_id;
        this.car_id = car_id;
        this.startDate = startDate;
        this.startTime = startTime;
        this.endDate = endDate;
        this.endTime = endTime;
    }

    @Override
    public int getID() {
        return ID;
    }

    @Override
    public void setID(int ID) {
        this.ID = ID;
    }

    public int getCar_renter_id() {
        return car_renter_id;
    }

    public void setCar_renter_id(int car_renter_id) {
        this.car_renter_id = car_renter_id;
    }

    public int getCar_id() {
        return car_id;
    }

    public void setCar_id(int car_id) {
        this.car_id = car_id;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }
}
