
<img src="https://i.imgur.com/ICQQNUH.jpg">

# Viktig

* Hva er problem stillingen?

*	Hva handler systemet om?

*	Lage prosjekt dokumentasjon og prototypen for en bedrift som har tjenester (Kunden kan leie ut bilen sin).

*	Hva er kjernesystem og miljø, hvilken funksjon er obligatorisk å ha med?


*	Hva er MVP?

*	MVP henger med krav.

*	Prototype = MVP 


*	Vi kan velge hovedfunksjoner som har verdi til kunden

*	Hva er omfang

*	Hva er dokumentasjon og hva er kravene?


*	Se hvordan vi kan gjøre dokumentasjon profesjonelt!

*	Se på t-skjorte estimerings metode for hvert enkelt krav

*	Teste om krav fungere slik at MVP er gyldig!

*	Prototypen skal ha persistent lagring/dynamisk 

*	Sørge at det er enkelt for kunden.

*	Pass på at dere avgrenser hva system skal gjøre og hva som håndteres av andre eksterne partnerne.

*	Oppgaven skal levres som en GitHub rep

*	Må sjekke pakkesystem for testing

*	Lage sekvens diagramer for funksjonene vi har.





