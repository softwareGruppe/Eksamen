package tools;
import com.fasterxml.jackson.databind.SerializationFeature;
import models.Car;
import models.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;


public class JsonFileHandler {

    public JsonFileHandler() {
        //creating an empty constructor to prevent error when deserializing and reading from json file.
    }

    ArrayList<Car> cars = new ArrayList<>();

    File carJson = new File("src/main/java/jsonDatabase/listing.json");

    ArrayList<Car> carList = readCarFromJSONfile(carJson);

    ArrayList<User> user = new ArrayList<>();

    File userJson = new File("src/main/java/jsonDatabase/user.json");

    ArrayList<User> userList = readUserFromJSONfile(userJson);


    //metode for å lese en JSON-fil og returnere innholdet som en ArrayList med bil-objekter
    public ArrayList<Car> readCarFromJSONfile(File fil) {
        ArrayList<Car> returnCarListe = new ArrayList<>();

        ObjectMapper objectMapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);

        try {
            Car[] carArray = objectMapper.readValue(fil, Car[].class);

            returnCarListe.addAll(Arrays.asList(carArray));

        } catch (IOException e) {
            e.printStackTrace();
        }

        //returnerer listen med bil-objekter lest fra JSON-fil
        return returnCarListe;
    }

    //metode for å lese en JSON-fil og returnere innholdet som en ArrayList med user-objekter
    public ArrayList<User> readUserFromJSONfile(File fil) {

        ArrayList<User> returnUserListe = new ArrayList<>();

        ObjectMapper objectMapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);

        try {
            User[] userArray = objectMapper.readValue(fil, User[].class);

            returnUserListe.addAll(Arrays.asList(userArray));

        } catch (IOException e) {
            e.printStackTrace();
        }

        //returnerer listen med user-objekter lest fra JSON-fil
        return returnUserListe;
    }


}
