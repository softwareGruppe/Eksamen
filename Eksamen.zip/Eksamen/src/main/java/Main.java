import forms.rentYourCarGUI;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        JFrame mainWindow = new rentYourCarGUI("RentYourCar");
        mainWindow.setVisible(true);
    }
}
